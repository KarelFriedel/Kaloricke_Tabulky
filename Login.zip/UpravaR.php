<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upravit recept</title>
</head>
<body>
    <h2>Vyberte recept k úpravě nebo smazání:</h2>
    <form action="" method="post">
        <table>
            <tr>
                <th>ID</th>
                <th>Název receptu</th>
                <th>Vybrat</th>
                <th>Smazat</th>
            </tr>
            <?php
            // Připojení k databázi a načtení názvů všech receptů
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "kaloricke_tabulky";

            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT ID, Nazev FROM recepty";
            $result = $conn->query($sql);

            // Vytvoření řádků tabulky pro výběr receptu nebo smazání
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['ID'] . "</td>";
                echo "<td>" . $row['Nazev'] . "</td>";
                echo "<td><button type='submit' name='recept' value='" . $row['ID'] . "'>Upravit Recept</button></td>";
                echo "<td><button type='submit' name='smzat_recept' value='" . $row['ID'] . "'>Smazat recept</button></td>";
                echo "</tr>";
            }
            ?>
        </table>
    </form>

    <?php
    // Zpracování formuláře pro smazání receptu
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['smazat_recept'])) {
        $recept_id = $_POST['smazat_recept'];

        $sql_delete_recepty_potraviny = "DELETE FROM recepty_potraviny WHERE Recept_ID = $recept_id";
        $sql_delete_recepty = "DELETE FROM recepty WHERE ID = $recept_id";

        if ($conn->query($sql_delete_recepty_potraviny) === TRUE && $conn->query($sql_delete_recepty) === TRUE && $conn->query($sql_delete_potraviny) === TRUE) {
            echo "Recept byl úspěšně smazán.";
        } else {
            echo "Chyba při mazání receptu: " . $conn->error;
        }
    }

    $conn->close();
    ?>
</body>
</html>
