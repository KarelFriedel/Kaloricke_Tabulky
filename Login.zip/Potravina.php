<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Přidat potravinu</title>
    <style>
        body {
            background-color: #078f5be1;
            font-family: Arial, sans-serif;
        }

        .login-container {
            background-color: #fff;
            max-width: 40%;
            margin: 0 auto;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .login-header {
            text-align: center;
        }

        .login-header h1 {
            color: #008000;
        }

        .login-form input, .login-form select {
            width: calc(100% - 20px);
            margin: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .login-form button {
            width: calc(100% - 20px);
            margin: 10px;
            padding: 10px;
            background-color: #008000;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .error {
            color: red;
        }

    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>Přidat potravinu</h1>
        </div>
        <form class="login-form" action="" method="post">
            <label for="nazev">Název potraviny:</label><br>
            <input type="text" id="nazev" name="nazev" required><br><br>
            <label for="energie">Energetická hodnota (kcal):</label><br>
            <input type="number" id="energie" name="energie" min="0" required><br><br>
            <label for="bilkoviny">Bílkoviny (g):</label><br>
            <input type="number" id="bilkoviny" name="bilkoviny" min="0"><br><br>
            <label for="sacharidy">Sacharidy (g):</label><br>
            <input type="number" id="sacharidy" name="sacharidy" min="0"><br><br>
            <label for="tuky">Tuky (g):</label><br>
            <input type="number" id="tuky" name="tuky" min="0"><br><br>
            <label for="vlaknina">Vláknina (g):</label><br>
            <input type="number" id="vlaknina" name="vlaknina" min="0"><br><br>
            <button type="submit">Přidat potravinu</button>
        </form>
    </div>
</body>
</html>
