<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Přidat novou aktivitu</title>
<style>
    body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .container {
        width: 100%;
        height:100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    .form-popup {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        padding: 20px;
        background-color: #fff;
        border: 1px solid #ccc;
        z-index: 9999;
    }
    .my-button {
        padding: 15px 25px; 
        background-color: #4CAF50; 
        color: #fff; 
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    .my-button:hover {
        background-color: #45a049;
    }
    input[type="text"] {
        width: 100%;
        padding: 10px;
        margin: 5px 0;
        box-sizing: border-box;
    }
    .form-submit-button {
        padding: 10px 20px;
        background-color: #4CAF50;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    .form-submit-button:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>

<div class="container">
    <button class="my-button" onclick="openForm()">Přidat novou aktivitu</button>
</div>

<div id="myForm" class="form-popup">
    <form action="" method="post">
        <label for="nazevAktivity">Název aktivity:</label>
        <input type="text" id="nazevAktivity" name="nazevAktivity" required>
        <label for="casMinut">Čas cvičení (minuty):</label>
        <input type="text" id="casMinut" name="casMinut" required>
        <label for="datum">Datum:</label>
        <input type="text" id="datum" name="datum" required>
        <button type="submit" class="form-submit-button">Přidat aktivitu</button>
        <button type="button" class="form-submit-button" onclick="closeForm()">Zavřít</button>
    </form>
</div>

<script>
    function openForm() {
        document.getElementById("myForm").style.display = "block";
    }

    function closeForm() {
        document.getElementById("myForm").style.display = "none";
    }
</script>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['id_Uzivatele'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kaloricke_tabulky";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Chyba připojení k databázi: " . $conn->connect_error);
}

function pridejAktivitu($nazevAktivity, $casMinut, $datum)
{
    global $conn;

    $sql = "INSERT INTO cviceni (id_aktivity, doba_cviceni, datum, Id_Uzivatele)
            VALUES ((SELECT Id_Aktivity FROM aktivity WHERE Nazev_Aktivity = ?), ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Chyba při přípravě dotazu: " . $conn->error);
    }

    $stmt->bind_param("sisi", $nazevAktivity, $casMinut, $datum, $_SESSION['id_Uzivatele']);

    try {
        if ($stmt->execute()) {
            echo "Aktivita byla úspěšně přidána.";
        } else {
            throw new Exception("Chyba při vkládání aktivity: " . $stmt->error
