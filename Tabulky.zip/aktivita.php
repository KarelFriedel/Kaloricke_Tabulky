<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pět divů ve středu obrazovky</title>
<!-- Připojení ikonové knihovny Material Icons -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
    body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .container {
        width: 100%;
        height:100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    .stripe {
        height: 7%;
        width: 50%;
        background-color: rgb(222, 222, 222); 
        margin: 5px 0; 
        text-align: center; 
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 10px;
    }
    .material-icons {
        font-size: 24px; /* Velikost ikon */
        margin-left: auto; /* Ikony zarovnané vpravo */
    }
</style>
</head>
<body>

<div class="container">
    <!-- Použití ikon z Material Icons -->
    <div class="stripe">Snídaně <span class="material-icons">water_drop</span> <span class="material-icons">restaurant </span></div>
    <div class="stripe">Oběd<span class="material-icons">water_drop</span> <span class="material-icons">restaurant </span></div>
    <div class="stripe">večeře <span class="material-icons">water_drop</span> <span class="material-icons">restaurant </span></div>

</div>

</body>
</html>
