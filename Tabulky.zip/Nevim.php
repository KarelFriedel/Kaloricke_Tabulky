<?php
function insert_custom_food() {
    
    $servername = "localhost";
    $username = "root"; // Změňte na své uživatelské jméno
    $password = ""; // Změňte na své heslo
    $dbname = "kaloricke_tabulky";

    $conn = new mysqli($servername, $username, $password, $dbname);

   
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nazev = $_POST["nazevPotraviny"];
        $energie = $_POST["energetickaHodnota"];
        $bilkoviny = $_POST["bilkoviny"];
        $sacharidy = $_POST["sacharidy"];
        $tuky = $_POST["tuky"];
        $vlaknina = $_POST["vlaknina"];

    
        $sql = "INSERT INTO potraviny (Nazev_Potraviny, Energeticka_Hodnota, Bílkoviny, Sacharidy, Tuky, Vláknina)
                VALUES ('$nazev', '$energie', '$bilkoviny', '$sacharidy', '$tuky', '$vlaknina')";

        if ($conn->query($sql) === TRUE) {
            echo "Nová potravina byla úspěšně přidána.";
        } else {
            echo "Chyba při přidávání potraviny: " . $conn->error;
        }
    }

   
    $conn->close();
}


insert_custom_food();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Vlastní potravina</title>
<style>
    body, html {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .container {
        width: 100%;
        height:100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    .form-popup {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        padding: 20px;
        background-color: #fff;
        border: 1px solid #ccc;
        z-index: 9999;
    }
    .my-button {
        padding: 15px 25px; 
        background-color: #4CAF50; 
        color: #fff; 
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    .my-button:hover {
        background-color: #45a049;
    }
    input[type="text"] {
        width: 100%;
        padding: 10px;
        margin: 5px 0;
        box-sizing: border-box;
    }
    .form-submit-button {
        padding: 10px 20px;
        background-color: #4CAF50;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    .form-submit-button:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>

<div class="container">
    <button class="my-button" onclick="PridatPotravinu()">Vlastní potravina</button>
</div>

<div id="myForm" class="form-popup">
    <form action="Nevim.php" method="post">
        <label for="nazevPotraviny">Název potraviny:</label>
        <input type="text" id="nazevPotraviny" name="nazevPotraviny" required>
        <label for="energetickaHodnota">Energetická hodnota: (kcal/100g)</label>
        <input type="text" id="energetickaHodnota" name="energetickaHodnota" required>
        <label for="bilkoviny">Bílkoviny: (kcal/100g)</label>
        <input type="text" id="bilkoviny" name="bilkoviny">
        <label for="sacharidy">Sacharidy: (kcal/100g)</label>
        <input type="text" id="sacharidy" name="sacharidy">
        <label for="tuky">Tuky: (kcal/100g)</label>
        <input type="text" id="tuky" name="tuky">
        <label for="vlaknina">Vláknina: (kcal/100g)</label>
        <input type="text" id="vlaknina" name="vlaknina">
        <button type="submit" class="form-submit-button">Přidat potravinu</button>
        <button type="button" class="form-submit-button" onclick="ZavriPridatPotravinu()">Zavřít</button>
    </form>
</div>

<script>
    function PridatPotravinu() {
        document.getElementById("myForm").style.display = "block";
    }

    function ZavriPridatPotravinu() {
        document.getElementById("myForm").style.display = "none";
    }
</script>

</body>
</html>
